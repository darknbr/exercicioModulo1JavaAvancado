package br.com.mentorama.exercicioModulo1JavaAvancado;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExercicioModulo1JavaAvancadoApplicationTests {

	@Test
	void contextLoads() {
	}

}
