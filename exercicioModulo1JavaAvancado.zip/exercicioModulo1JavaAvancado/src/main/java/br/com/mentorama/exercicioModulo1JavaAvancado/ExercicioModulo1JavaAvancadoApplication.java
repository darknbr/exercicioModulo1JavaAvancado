package br.com.mentorama.exercicioModulo1JavaAvancado;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExercicioModulo1JavaAvancadoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExercicioModulo1JavaAvancadoApplication.class, args);
	}

}
